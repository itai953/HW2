Advanced CPP course EX2

Elyashiv Cohen  316534353

Itai Sharoni 313390502
